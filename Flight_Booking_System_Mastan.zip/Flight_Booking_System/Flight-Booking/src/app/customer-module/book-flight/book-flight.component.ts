import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { FlightService } from 'src/app/flight.service';

@Component({
  selector: 'app-book-flight',
  templateUrl: './book-flight.component.html',
  styleUrls: ['./book-flight.component.scss']
})
export class BookFlightComponent implements OnInit {
  
  bookForm:FormGroup;

  constructor(private flightService:FlightService) { 
    this.bookForm = new FormGroup({
      from:new FormControl(""),
      to:new FormControl(""),
      phone:new FormControl(""),
      email:new FormControl(""),
      departure:new FormControl(""),
      adults:new FormControl(""),
      children:new FormControl("")
  });
  }

  ngOnInit(): void {
   
  }

  getRegister(){
    let a=this.bookForm.get("from")?.value;
    
    let flight={
      from:a,
      to:this.bookForm.get("to")?.value,
      phone:this.bookForm.get("phone")?.value,
      email:this.bookForm.get("email")?.value,
      departure:this.bookForm.get("departure")?.value,
      adults:this.bookForm.get("adults")?.value,
      child:this.bookForm.get("children")?.value
    };
    console.log(flight);
    
    this.flightService.bookTicket(flight)
    .subscribe((res:any)=>{
      console.log(res);
    })
  }

}
