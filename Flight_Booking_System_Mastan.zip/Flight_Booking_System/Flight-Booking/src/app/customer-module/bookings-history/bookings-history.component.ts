import { Component, OnInit } from '@angular/core';
import { FlightService } from 'src/app/flight.service';

@Component({
  selector: 'app-bookings-history',
  templateUrl: './bookings-history.component.html',
  styleUrls: ['./bookings-history.component.scss']
})
export class BookingsHistoryComponent implements OnInit {

  flightsHistory:any[] = [];

  constructor(private flightService:FlightService) { 
   
  }

  ngOnInit(): void {
    this.flightService.findAllTickets()
    .subscribe((res:any)=>{
      this.flightsHistory = res;
    })
    console.log([...this.flightsHistory]);
  }

  flightsList=[
    {airline:"Alaska Airlines", flightNo:'AS1', route: "India-Alaska" , travelDate:"29 Mar 2021"},
    {airline:"American Airlines", flightNo:'AA1', route: "India-USA", travelDate:"30 Jan 2021"},
    {airline:"American Eagle", flightNo:'AS1', route: "India-USA", travelDate:"05 May 2021"},
  ];



}
