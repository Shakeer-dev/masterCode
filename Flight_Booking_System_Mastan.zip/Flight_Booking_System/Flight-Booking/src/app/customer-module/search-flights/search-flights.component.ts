import { Component, OnInit } from '@angular/core';
import { FlightService } from 'src/app/flight.service';

@Component({
  selector: 'app-search-flights',
  templateUrl: './search-flights.component.html',
  styleUrls: ['./search-flights.component.scss']
})
export class SearchFlightsComponent implements OnInit {
 
  flights:any[] = [];

  constructor(private flightService:FlightService) {
   }

  ngOnInit(): void {
    this.flightService.findAllflights()
    .subscribe((res:any)=>{
      this.flights = res;
    })
    console.log([...this.flights]);
  }

  // flightsList=[
  //   {airline:"Alaska Airlines", flightNo:'AS1', route: "India-Alaska"},
  //   {airline:"American Airlines", flightNo:'AA1', route: "India-USA"},
  //   {airline:"American Eagle", flightNo:'AS1', route: "India-USA"},
  //   {airline:"Air Canada Express", flightNo:'ACS1', route: "Kingston-Toronto Pearson"},
  //   {airline:"AirAsia X", flightNo:'AX1', route: "India-Seattle"}
  // ];

  findflights(){
    this.flightService.findAllflights()
    .subscribe((res:any)=>{
      this.flights = res;
    })
    console.log([...this.flights]);
  }
}
