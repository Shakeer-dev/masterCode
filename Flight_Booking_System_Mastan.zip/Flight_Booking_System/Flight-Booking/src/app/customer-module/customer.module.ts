import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BookFlightComponent } from './book-flight/book-flight.component';
import { SearchFlightsComponent } from './search-flights/search-flights.component';
import { BookingsHistoryComponent } from './bookings-history/bookings-history.component';
import { HeaderComponent } from './header/header.component';


const routes: Routes=[
  {path: 'home', component: HeaderComponent},
  {path: 'flightBooking', component: BookFlightComponent},
  {path: 'bookingsHistory', component: BookingsHistoryComponent},
  {path: 'searchFlights', component: SearchFlightsComponent},
];
@NgModule({
  declarations: [
    BookFlightComponent,
    BookingsHistoryComponent,
    SearchFlightsComponent,
    HeaderComponent
  ],
  imports: [
    FormsModule,
    ReactiveFormsModule,
    CommonModule,
    RouterModule.forChild(routes)
  ],
  bootstrap: [HeaderComponent]
})
export class CustomerModule { }
