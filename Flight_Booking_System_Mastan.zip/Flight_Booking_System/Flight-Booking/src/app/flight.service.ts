import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class FlightService {

   HOST:string = "http://localhost:3000/flights";
   ticketUrl:string = "http://localhost:3000/tickets";

    constructor(private http:HttpClient) { 
    
    }

    bookTicket(ticket: { from: any; to: any; phone: any; email: any; departure: any; adults: any; child: any; }){
      return this.http.post(this.ticketUrl, ticket);
    }

    findAllflights(){
      return this.http.get(this.HOST);
    }

    findAllTickets(){
      return this.http.get(this.ticketUrl);
    }

  }

