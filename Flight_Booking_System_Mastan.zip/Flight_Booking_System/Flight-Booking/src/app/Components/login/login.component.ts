import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {

  myForm:FormGroup;

  constructor(private router: Router){
    this.myForm = new FormGroup({

      username: new FormControl("User", [
        Validators.required,
        Validators.pattern("^[A-Za-z]")
      ]),
      
      password: new FormControl("123", Validators.required)
  
  });
  }

  ngOnInit(): void {
  }
  getLogin(){
    if(this.myForm.value.username=="user"){
      console.log("Hello User");
      //this.router.navigate(['customer']);
    }else if(this.myForm.value.username=="admin"){
      //this.router.navigate(['admin']);
    }

}
}
