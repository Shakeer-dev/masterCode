import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sgin-up',
  templateUrl: './sgin-up.component.html',
  styleUrls: ['./sgin-up.component.scss']
})
export class SginUpComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
