import { ModuleWithComponentFactories, NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';

import { ManageschedulesComponent } from './admin-module/manageschedules/manageschedules.component';
import { ManagediscountsComponent } from './admin-module/managediscounts/managediscounts.component';
import { ManageairlinesComponent } from './admin-module/manageairlines/manageairlines.component';
import { BookFlightComponent } from './customer-module/book-flight/book-flight.component';
import { BookingsHistoryComponent } from './customer-module/bookings-history/bookings-history.component';
import { SearchFlightsComponent } from './customer-module/search-flights/search-flights.component';
import { RouterModule, Routes } from '@angular/router';
import { HeaderComponent } from './customer-module/header/header.component';
import { LoginComponent } from './Components/login/login.component';
import { SginUpComponent } from './Components/sgin-up/sgin-up.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';

const routes: Routes=[
  {path:"login", component:LoginComponent},
  {path:"singup", component:SginUpComponent},
  {path : "customer",
           loadChildren:()=>import('./customer-module/customer.module').then(module=>module.CustomerModule)},
  {path : "admin",
           loadChildren:()=>import('./admin-module/admin.module').then(module=>module.AdminModule)}         
];
@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    SginUpComponent
  ],
  imports: [
    HttpClientModule,
    BrowserModule,
    FormsModule,
    ReactiveFormsModule,
   RouterModule.forRoot(routes)
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
