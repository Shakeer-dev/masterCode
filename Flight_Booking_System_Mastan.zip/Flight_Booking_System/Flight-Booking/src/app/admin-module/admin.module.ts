import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ManageairlinesComponent } from './manageairlines/manageairlines.component';
import { ManagediscountsComponent } from './managediscounts/managediscounts.component';
import { ManageschedulesComponent } from './manageschedules/manageschedules.component';
import { RouterModule, Routes } from '@angular/router';
import { HeaderComponent } from './header/header.component';


const routes: Routes=[
  {path: 'home', component: HeaderComponent},
  {path: 'manageSchedules', component: ManageschedulesComponent},
  {path: 'manageDiscounts', component: ManagediscountsComponent},
  {path: 'manageAirLines', component: ManageairlinesComponent},
];
@NgModule({
  declarations: [
    ManageschedulesComponent,
    ManagediscountsComponent,
    ManageairlinesComponent,
    HeaderComponent
  ],
  imports: [
    CommonModule,
    RouterModule.forChild(routes)
  ]
})
export class AdminModule { }
