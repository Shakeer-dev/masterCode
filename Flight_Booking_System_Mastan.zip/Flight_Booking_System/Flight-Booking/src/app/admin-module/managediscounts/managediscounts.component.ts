import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-managediscounts',
  templateUrl: './managediscounts.component.html',
  styleUrls: ['./managediscounts.component.scss']
})
export class ManagediscountsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
