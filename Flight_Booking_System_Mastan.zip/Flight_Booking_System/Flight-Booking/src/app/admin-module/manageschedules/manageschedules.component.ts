import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-manageschedules',
  templateUrl: './manageschedules.component.html',
  styleUrls: ['./manageschedules.component.scss']
})
export class ManageschedulesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
