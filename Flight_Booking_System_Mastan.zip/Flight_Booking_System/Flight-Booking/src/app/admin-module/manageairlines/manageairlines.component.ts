import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-manageairlines',
  templateUrl: './manageairlines.component.html',
  styleUrls: ['./manageairlines.component.scss']
})
export class ManageairlinesComponent implements OnInit {

 // myForm:FormGroup;
  
  constructor() {
  //   this.myForm = new FormGroup({

  //     password: new FormControl("123", Validators.required)
  
  // });

   }

  ngOnInit(): void {
  }

  getManaged(){

  }

}
